-- GENZ HUB KENYA database setup
-- Run this entire file in Supabase Dashboard > SQL Editor > New query.
-- IMPORTANT: Never put your Supabase service_role key in this website.

create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('opportunities','campus','voice','news')),
  title text not null check (char_length(title) between 3 and 100),
  description text not null check (char_length(description) between 5 and 1200),
  county text not null default 'National',
  source_url text,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 100),
  description text not null check (char_length(description) between 5 and 1200),
  category text,
  county text not null default 'National',
  website text,
  contact text,
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.community_posts (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 120),
  body text not null check (char_length(body) between 5 and 2000),
  county text not null default 'National',
  owner_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create index if not exists listings_status_created_idx on public.listings(status, created_at desc);
create index if not exists listings_type_county_idx on public.listings(type, county);
create index if not exists businesses_status_created_idx on public.businesses(status, created_at desc);
create index if not exists posts_status_created_idx on public.community_posts(status, created_at desc);

alter table public.admin_users enable row level security;
alter table public.listings enable row level security;
alter table public.businesses enable row level security;
alter table public.community_posts enable row level security;

-- Helper function: checks administrator membership without recursive RLS.
create or replace function public.is_hub_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users
    where user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_hub_admin() from public;
grant execute on function public.is_hub_admin() to authenticated;

-- Admin membership is readable only by the signed-in user for their own row,
-- or by another authorised admin. Users cannot insert/update their own admin role.
drop policy if exists "admin can read own membership" on public.admin_users;
create policy "admin can read own membership" on public.admin_users
for select to authenticated
using (user_id = (select auth.uid()) or public.is_hub_admin());

-- Listings: public sees approved entries; owners can submit and see their own;
-- only admins can see all submissions and moderate.
drop policy if exists "public read approved listings" on public.listings;
create policy "public read approved listings" on public.listings
for select to anon, authenticated
using (status = 'approved' or owner_id = (select auth.uid()) or public.is_hub_admin());

drop policy if exists "signed in users submit listings" on public.listings;
create policy "signed in users submit listings" on public.listings
for insert to authenticated
with check (owner_id = (select auth.uid()) and status = 'pending');

drop policy if exists "admins moderate listings" on public.listings;
create policy "admins moderate listings" on public.listings
for update to authenticated
using (public.is_hub_admin())
with check (public.is_hub_admin());

-- Business directory: same moderation model.
drop policy if exists "public read approved businesses" on public.businesses;
create policy "public read approved businesses" on public.businesses
for select to anon, authenticated
using (status = 'approved' or owner_id = (select auth.uid()) or public.is_hub_admin());

drop policy if exists "signed in users submit businesses" on public.businesses;
create policy "signed in users submit businesses" on public.businesses
for insert to authenticated
with check (owner_id = (select auth.uid()) and status = 'pending');

drop policy if exists "admins moderate businesses" on public.businesses;
create policy "admins moderate businesses" on public.businesses
for update to authenticated
using (public.is_hub_admin())
with check (public.is_hub_admin());

-- Community posts are moderated before publication.
drop policy if exists "public read approved posts" on public.community_posts;
create policy "public read approved posts" on public.community_posts
for select to anon, authenticated
using (status = 'approved' or owner_id = (select auth.uid()) or public.is_hub_admin());

drop policy if exists "signed in users submit posts" on public.community_posts;
create policy "signed in users submit posts" on public.community_posts
for insert to authenticated
with check (owner_id = (select auth.uid()) and status = 'pending');

drop policy if exists "admins moderate posts" on public.community_posts;
create policy "admins moderate posts" on public.community_posts
for update to authenticated
using (public.is_hub_admin())
with check (public.is_hub_admin());

grant select on public.admin_users to authenticated;
grant select, insert, update on public.listings to authenticated;
grant select, insert, update on public.businesses to authenticated;
grant select, insert, update on public.community_posts to authenticated;
grant select on public.listings to anon;
grant select on public.businesses to anon;
grant select on public.community_posts to anon;

-- ADMIN SETUP:
-- 1. Create your own account on the website.
-- 2. In Supabase Dashboard > Authentication > Users, copy that account's UUID.
-- 3. Run this SQL with your own UUID substituted:
--    insert into public.admin_users (user_id)
--    values ('YOUR-AUTH-USER-UUID');
-- Never let ordinary visitors choose or grant themselves admin access.
