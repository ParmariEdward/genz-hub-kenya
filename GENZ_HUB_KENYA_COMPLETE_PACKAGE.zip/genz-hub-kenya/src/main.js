import { createClient } from '@supabase/supabase-js';
import './style.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const configured = SUPABASE_URL.startsWith('https://') && SUPABASE_KEY.length > 20;
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const counties = [
  'Mombasa','Kwale','Kilifi','Tana River','Lamu','Taita Taveta','Garissa','Wajir','Mandera',
  'Marsabit','Isiolo','Meru','Tharaka Nithi','Embu','Kitui','Machakos','Makueni','Nyandarua',
  'Nyeri','Kirinyaga',"Murang'a",'Kiambu','Turkana','West Pokot','Samburu','Trans Nzoia',
  'Uasin Gishu','Elgeyo Marakwet','Nandi','Baringo','Laikipia','Nakuru','Narok','Kajiado',
  'Kericho','Bomet','Kakamega','Vihiga','Bungoma','Busia','Siaya','Kisumu','Homa Bay',
  'Migori','Kisii','Nyamira','Nairobi'
];

const departments = [
  {id:'opportunities', icon:'💼', en:'Jobs & Opportunities', sw:'Kazi na Fursa', desc:'Jobs, internships, attachments, scholarships and youth programmes.'},
  {id:'campus', icon:'🎓', en:'Campus Corner', sw:'Maisha ya Chuoni', desc:'Student resources, bursaries, HELB guidance and campus life.'},
  {id:'marketplace', icon:'🛍️', en:'Hustle Market', sw:'Soko la Vijana', desc:'Discover youth businesses, products and services.'},
  {id:'academy', icon:'💻', en:'Digital Academy', sw:'Chuo cha Kidijitali', desc:'Build practical skills in coding, AI and digital work.'},
  {id:'voice', icon:'🗣️', en:'Gen Z Voice', sw:'Sauti ya Vijana', desc:'Civic education, public participation and community conversations.'},
  {id:'news', icon:'📰', en:'Kenya Today', sw:'Habari za Kenya', desc:'Useful public information and updates that matter to young people.'}
];

const demoItems = [
  {id:'d1',type:'opportunities',title:'Find verified youth opportunities',description:'Opportunity listings will appear here after an administrator verifies and publishes them.',county:'National',source_url:'',status:'demo'},
  {id:'d2',type:'campus',title:'Student support and scholarship information',description:'Find official scholarship, bursary and student-support links. Always confirm eligibility with the issuing institution.',county:'National',source_url:'https://www.helb.co.ke/',status:'demo'},
  {id:'d3',type:'academy',title:'Start learning web development',description:'Learn the foundations of HTML, CSS and JavaScript using free learning resources.',county:'National',source_url:'https://developer.mozilla.org/',status:'demo'},
  {id:'d4',type:'voice',title:'Learn about public participation',description:'Understand how to follow county and national public participation notices.',county:'National',source_url:'https://www.parliament.go.ke/',status:'demo'}
];

const state = {
  lang:'en', page:'home', user:null, isAdmin:false, county:'All counties',
  search:'', listings:[], businesses:[], posts:[], notice:''
};

const app = document.querySelector('#app');
const t = (en,sw) => state.lang === 'en' ? en : sw;
const esc = (value='') => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const countyOptions = (selected='All counties') => ['All counties',...counties].map(c=>`<option ${c===selected?'selected':''} value="${esc(c)}">${esc(c)}</option>`).join('');

function shell() {
  const links = [
    ['home','⌂',t('Home','Nyumbani')],
    ['opportunities','💼',t('Opportunities','Fursa')],
    ['campus','🎓',t('Campus','Chuoni')],
    ['marketplace','🛍️',t('Hustle Market','Soko')],
    ['academy','💻',t('Learn','Jifunze')],
    ['voice','🗣️',t('Gen Z Voice','Sauti')],
    ['news','📰',t('Kenya Today','Habari')]
  ];
  app.innerHTML = `
    <header class="topbar">
      <a class="brand" href="#" data-page="home"><span class="flag">🇰🇪</span><span><b>GENZ HUB</b><small>KENYA</small></span></a>
      <div class="top-actions">
        <button class="lang-btn" id="langBtn">${state.lang==='en'?'Kiswahili':'English'}</button>
        ${state.user ? `<button class="account-btn" id="accountBtn">👤 ${esc(state.user.email.split('@')[0])}</button>` : `<button class="account-btn" id="accountBtn">${t('Sign in','Ingia')}</button>`}
      </div>
    </header>
    <nav class="nav">${links.map(([id,icon,label])=>`<button data-page="${id}" class="nav-item ${state.page===id?'selected':''}"><span>${icon}</span>${label}</button>`).join('')}</nav>
    <main id="main" class="container"></main>
    <footer><b>GENZ HUB KENYA 🇰🇪</b><p>${t('Your Life. Your Opportunities. Your Voice.','Maisha yako. Fursa zako. Sauti yako.')}</p><small>Independent youth information platform · Verify opportunities with the original provider.</small><small>© ${new Date().getFullYear()} GENZ HUB KENYA</small></footer>
    <div id="modal-root"></div>
    <div id="toast" class="toast" role="status"></div>`;
  document.querySelectorAll('[data-page]').forEach(el=>el.addEventListener('click',()=>navigate(el.dataset.page)));
  document.querySelector('#langBtn').addEventListener('click',()=>{state.lang=state.lang==='en'?'sw':'en';render();});
  document.querySelector('#accountBtn').addEventListener('click',()=>state.user?openAccount():openAuth());
  renderPage();
}

function navigate(page) { state.page=page; state.search=''; render(); window.scrollTo({top:0,behavior:'smooth'}); }

function renderPage() {
  const main = document.querySelector('#main');
  if (!main) return;
  if (state.page==='home') main.innerHTML = homePage();
  else if (state.page==='admin') main.innerHTML = adminPage();
  else if (state.page==='submit') main.innerHTML = submitPage();
  else if (state.page==='marketplace') main.innerHTML = marketPage();
  else if (state.page==='voice') main.innerHTML = voicePage();
  else if (state.page==='academy') main.innerHTML = academyPage();
  else main.innerHTML = directoryPage(state.page);
  bindPageEvents();
}

function homePage() {
  const cards = departments.map(d=>`<button class="dept-card" data-page="${d.id}"><span class="dept-icon">${d.icon}</span><b>${esc(t(d.en,d.sw))}</b><small>${esc(d.desc)}</small><span class="card-arrow">Explore →</span></button>`).join('');
  return `
    <section class="hero">
      <div class="hero-copy"><span class="eyebrow">BUILT FOR KENYAN YOUTH</span><h1>${t('Your next opportunity starts here.','Fursa yako inayofuata inaanzia hapa.')}</h1><p>${t('Discover opportunities, grow your skills, support youth businesses and make your voice heard — across all 47 counties.','Pata fursa, jenga ujuzi, saidia biashara za vijana na usikike — katika kaunti zote 47.')}</p>
      <div class="hero-actions"><button class="primary-btn" data-page="opportunities">${t('Explore opportunities','Angalia fursa')} ↗</button><button class="ghost-btn" data-page="academy">${t('Learn new skills','Jifunze ujuzi')}</button></div></div>
      <div class="hero-art"><div class="orbit orbit-one"></div><div class="orbit orbit-two"></div><div class="hero-emoji">🇰🇪</div><span class="bubble bubble-one">💡 Ideas</span><span class="bubble bubble-two">🚀 Growth</span><span class="bubble bubble-three">🤝 Connect</span></div>
    </section>
    <section class="search-panel"><div><b>${t('What are you looking for?','Unatafuta nini?')}</b><small>${t('Search across GENZ HUB','Tafuta kwenye GENZ HUB')}</small></div><input id="globalSearch" placeholder="${t('Try jobs, scholarships, coding…','Jaribu kazi, ufadhili, coding…')}" value="${esc(state.search)}"><select id="countyFilter">${countyOptions(state.county)}</select><button class="primary-btn" id="searchBtn">${t('Search','Tafuta')}</button></section>
    <section class="section-head"><div><span class="eyebrow">ONE HUB · MANY POSSIBILITIES</span><h2>${t('Explore the hub','Chunguza huduma')}</h2></div><span class="county-count">47 COUNTIES</span></section>
    <div class="dept-grid">${cards}</div>
    <section class="wide-cta"><div><span class="eyebrow">YOUR VOICE MATTERS</span><h2>${t('Kenya moves forward when young people participate.','Kenya inasonga mbele vijana wanaposhiriki.')}</h2><p>${t('Learn how to take part in public life and make informed decisions.','Jifunze kushiriki katika masuala ya umma na kufanya maamuzi sahihi.')}</p></div><button class="light-btn" data-page="voice">${t('Explore Gen Z Voice','Tembelea Sauti ya Vijana')} →</button></section>
    <section class="section-head"><div><span class="eyebrow">START HERE</span><h2>${t('Useful starting points','Anza hapa')}</h2></div></section>
    <div class="quick-grid"><a href="https://www.helb.co.ke/" target="_blank" rel="noopener">🎓 <b>HELB</b><small>Official student financing information ↗</small></a><a href="https://www.mygov.go.ke/" target="_blank" rel="noopener">🏛️ <b>MyGov Kenya</b><small>Government notices and information ↗</small></a><a href="https://www.brightermonday.co.ke/" target="_blank" rel="noopener">💼 <b>BrighterMonday</b><small>Explore job listings ↗</small></a></div>`;
}

function directoryPage(type) {
  const dept=departments.find(d=>d.id===type);
  const items=state.listings.filter(x=>x.type===type && x.status==='approved');
  const demo=demoItems.filter(x=>x.type===type);
  const all=[...items,...demo];
  return `<section class="page-intro"><span class="eyebrow">${dept.icon} GENZ HUB KENYA</span><h1>${esc(t(dept.en,dept.sw))}</h1><p>${esc(dept.desc)}</p></section>
  <div class="toolbar"><input id="listSearch" placeholder="${t('Search this section…','Tafuta hapa…')}"><select id="listCounty">${countyOptions(state.county)}</select></div>
  <div class="listing-grid" id="listingGrid">${all.length?all.map(listingCard).join(''):`<div class="empty-state"><span>🔎</span><b>${t('No published listings yet','Hakuna matangazo yaliyochapishwa bado')}</b><p>${t('Check again later or submit a listing for review.','Rudi baadaye au wasilisha tangazo likaguliwe.')}</p></div>`}</div>
  <div class="submit-strip"><div><b>${t('Know about an opportunity?','Unafahamu fursa?')}</b><p>${t('Help other young Kenyans by submitting it for review.','Saidia vijana wengine kwa kuiwasilisha ikaguliwe.')}</p></div><button class="primary-btn" data-page="submit">${t('Submit a listing','Wasilisha tangazo')}</button></div>`;
}

function listingCard(x) {
  const badge=x.status==='demo'?'DEMO / RESOURCE':'VERIFIED · PUBLISHED';
  return `<article class="listing-card"><div class="listing-top"><span class="status-pill ${x.status==='demo'?'demo':'approved'}">${badge}</span><span class="small">${esc(x.county||'National')}</span></div><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p>${x.source_url?`<a class="text-link" href="${esc(x.source_url)}" target="_blank" rel="noopener">Visit source ↗</a>`:''}</article>`;
}

function marketPage() {
  const items=state.businesses;
  return `<section class="page-intro"><span class="eyebrow">🛍️ LOCAL IDEAS · NATIONAL REACH</span><h1>Hustle Market</h1><p>Discover youth-owned businesses and services. Listings are published only after review.</p></section>
  <div class="submit-strip"><div><b>Promote a youth business</b><p>Submit your business details for administrator review.</p></div><button class="primary-btn" data-page="submit">Submit a business</button></div>
  <div class="listing-grid">${items.length?items.map(x=>`<article class="listing-card"><span class="status-pill approved">REVIEWED LISTING</span><h3>${esc(x.name)}</h3><p>${esc(x.description)}</p><small>${esc(x.county)} · ${esc(x.category||'Youth business')}</small>${x.contact?`<p class="contact-line">Contact: ${esc(x.contact)}</p>`:''}${x.website?`<a class="text-link" href="${esc(x.website)}" target="_blank" rel="noopener">Visit website ↗</a>`:''}</article>`).join(''):'<div class="empty-state"><span>🛍️</span><b>No businesses published yet</b><p>Be among the first to submit a youth business for review.</p></div>'}</div>`;
}

function academyPage() {
  const resources=[
    ['🌐','MDN Web Docs','Free documentation for HTML, CSS and JavaScript.','https://developer.mozilla.org/'],
    ['🧠','Microsoft Learn','Free learning paths in technology and digital skills.','https://learn.microsoft.com/training/'],
    ['🤖','Elements of AI','An introductory course to understand artificial intelligence.','https://www.elementsofai.com/'],
    ['📊','Google Digital Skills','Explore digital marketing and career learning resources.','https://grow.google/'],
    ['🛡️','Cybersecurity basics','Learn online safety and responsible security practices.','https://www.cisa.gov/secure-our-world']
  ];
  return `<section class="page-intro"><span class="eyebrow">💻 LEARN · BUILD · GROW</span><h1>Digital Academy</h1><p>Start with free, trusted learning resources. Learn at your own pace and practise responsibly.</p></section><div class="resource-grid">${resources.map(r=>`<a class="resource-card" href="${r[3]}" target="_blank" rel="noopener"><span>${r[0]}</span><b>${r[1]}</b><p>${r[2]}</p><small>Open learning resource ↗</small></a>`).join('')}</div>`;
}

function voicePage() {
  return `<section class="page-intro"><span class="eyebrow">🗣️ INFORM · PARTICIPATE · CONTRIBUTE</span><h1>Gen Z Voice</h1><p>A space for civic learning and constructive participation. Respectful debate, facts and peaceful engagement come first.</p></section>
  <div class="voice-grid"><a class="voice-card" href="https://www.parliament.go.ke/" target="_blank" rel="noopener"><span>🏛️</span><b>National Parliament</b><p>Follow parliamentary business, bills and public information.</p><small>Visit Parliament ↗</small></a><a class="voice-card" href="https://cog.go.ke/" target="_blank" rel="noopener"><span>🏘️</span><b>Council of Governors</b><p>Explore county governance and devolution information.</p><small>Visit CoG ↗</small></a><a class="voice-card" href="https://www.iebc.or.ke/" target="_blank" rel="noopener"><span>🗳️</span><b>IEBC</b><p>Find official electoral and voter education information.</p><small>Visit IEBC ↗</small></a></div>
  <div class="notice-card"><b>Community standards</b><p>We support peaceful, lawful civic participation. No hate speech, threats, harassment, doxxing or calls for violence. Public posts will require moderation before publication.</p></div>
  <div class="submit-strip"><div><b>Have a constructive community topic?</b><p>Submit it for moderation and possible publication.</p></div><button class="primary-btn" data-page="submit">Submit a post</button></div>`;
}

function submitPage() {
  if (!state.user) return `<section class="page-intro"><h1>Sign in to contribute</h1><p>You need an account to submit a listing or community post. Public browsing remains available without an account.</p><button class="primary-btn" id="openAuth">Sign in / Create account</button></section>`;
  return `<section class="page-intro"><span class="eyebrow">CONTRIBUTE TO THE HUB</span><h1>Submit for review</h1><p>Submissions are not published automatically. An administrator checks them first.</p></section>
  <form class="form-card" id="submissionForm">
    <label>What are you submitting?<select name="kind" id="submissionKind"><option value="opportunity">Job / opportunity</option><option value="campus">Campus information</option><option value="business">Youth business</option><option value="voice">Community topic</option></select></label>
    <label>Title / business name<input name="title" required maxlength="100" placeholder="Enter a clear title"></label>
    <label>Description<textarea name="description" required maxlength="1200" rows="4" placeholder="Give accurate, useful details"></textarea></label>
    <label>County<select name="county">${countyOptions('National').replace('<option value="All counties">All counties</option>','<option value="National">National / All counties</option>')}</select></label>
    <label>Official source or website (optional)<input name="source_url" type="url" placeholder="https://..."></label>
    <label>Contact details (business listings only, optional)<input name="contact" maxlength="100" placeholder="Business email or public contact"></label>
    <button class="primary-btn full" type="submit">Send for review</button>
    <small class="form-note">Do not submit passwords, ID numbers, private medical details or another person's personal information. Never pay someone promising a job.</small>
  </form>`;
}

function adminPage() {
  if (!state.user || !state.isAdmin) return `<section class="page-intro"><h1>Admin access</h1><p>This area is restricted to authorised administrators.</p></section>`;
  const pending=state.listings.filter(x=>x.status==='pending');
  return `<section class="page-intro"><span class="eyebrow">CONTROL CENTRE</span><h1>Admin dashboard</h1><p>Review submissions before anything is published.</p></section><div class="admin-stats"><div><b>${pending.length}</b><small>Pending submissions</small></div><div><b>${state.listings.filter(x=>x.status==='approved').length}</b><small>Published opportunities</small></div></div><h2 class="subhead">Pending submissions</h2><div class="listing-grid">${pending.length?pending.map(x=>`<article class="listing-card"><span class="status-pill pending">PENDING REVIEW</span><h3>${esc(x.title)}</h3><p>${esc(x.description)}</p><small>${esc(x.type)} · ${esc(x.county||'National')}</small><div class="admin-actions"><button class="primary-btn" data-approve="${x.id}">Approve</button><button class="danger-btn" data-reject="${x.id}">Reject</button></div></article>`).join(''):'<div class="empty-state">No pending submissions.</div>'}</div>`;
}

function openAuth() {
  document.querySelector('#modal-root').innerHTML=`<div class="modal-backdrop" id="backdrop"><section class="modal"><button class="modal-close" id="closeModal">×</button><span class="eyebrow">WELCOME TO THE HUB</span><h2 id="authTitle">Sign in</h2><form id="authForm"><label>Email address<input name="email" type="email" required autocomplete="email"></label><label>Password<input name="password" type="password" required minlength="8" autocomplete="current-password"></label><button class="primary-btn full" id="authSubmit">Sign in</button></form><button class="switch-auth" id="switchAuth">New here? Create an account</button><p class="form-note">Use an email address you control. Never share your password.</p></section></div>`;
  let signup=false;
  document.querySelector('#closeModal').onclick=closeModal;
  document.querySelector('#backdrop').addEventListener('click',e=>{if(e.target.id==='backdrop')closeModal();});
  document.querySelector('#switchAuth').onclick=()=>{signup=!signup;document.querySelector('#authTitle').textContent=signup?'Create account':'Sign in';document.querySelector('#authSubmit').textContent=signup?'Create account':'Sign in';document.querySelector('#switchAuth').textContent=signup?'Already registered? Sign in':'New here? Create an account';};
  document.querySelector('#authForm').onsubmit=async e=>{
    e.preventDefault();const fd=new FormData(e.currentTarget);const email=fd.get('email').toString().trim();const password=fd.get('password').toString();
    if(!supabase) return toast('Connect Supabase first. See the setup guide.');
    busy(e.submitter,true);
    const result=signup?await supabase.auth.signUp({email,password}):await supabase.auth.signInWithPassword({email,password});
    busy(e.submitter,false);
    if(result.error) return toast(result.error.message);
    closeModal();
    if(signup && !result.data.session) toast('Check your email to confirm your account.');
    else {toast(signup?'Account created. Welcome!':'Signed in successfully.');await refreshData();}
  };
}

function openAccount() {
  document.querySelector('#modal-root').innerHTML=`<div class="modal-backdrop" id="backdrop"><section class="modal"><button class="modal-close" id="closeModal">×</button><span class="eyebrow">YOUR ACCOUNT</span><h2>${esc(state.user.email)}</h2><p class="form-note">You are signed in to GENZ HUB KENYA.</p>${state.isAdmin?'<button class="primary-btn full" id="adminOpen">Open admin dashboard</button>':''}<button class="danger-btn full" id="signOut">Sign out</button></section></div>`;
  document.querySelector('#closeModal').onclick=closeModal;
  document.querySelector('#backdrop').addEventListener('click',e=>{if(e.target.id==='backdrop')closeModal();});
  document.querySelector('#signOut').onclick=async()=>{await supabase.auth.signOut();closeModal();state.user=null;state.isAdmin=false;render();toast('Signed out.');};
  document.querySelector('#adminOpen')?.addEventListener('click',()=>{closeModal();navigate('admin');});
}

function closeModal(){document.querySelector('#modal-root').innerHTML='';}
function toast(message){const el=document.querySelector('#toast');if(!el)return;el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),3800);}
function busy(button,on){if(!button)return;button.disabled=on;button.dataset.original ||= button.textContent;button.textContent=on?'Please wait…':button.dataset.original;}

function bindPageEvents() {
  document.querySelectorAll('[data-page]').forEach(el=>el.addEventListener('click',()=>navigate(el.dataset.page)));
  document.querySelector('#searchBtn')?.addEventListener('click',()=>{state.search=document.querySelector('#globalSearch').value.trim();state.county=document.querySelector('#countyFilter').value;runSearch();});
  document.querySelector('#globalSearch')?.addEventListener('keydown',e=>{if(e.key==='Enter'){state.search=e.target.value.trim();state.county=document.querySelector('#countyFilter').value;runSearch();}});
  document.querySelector('#listSearch')?.addEventListener('input',filterListings);
  document.querySelector('#listCounty')?.addEventListener('change',filterListings);
  document.querySelector('#openAuth')?.addEventListener('click',openAuth);
  document.querySelector('#submissionForm')?.addEventListener('submit',submitForm);
  document.querySelectorAll('[data-approve]').forEach(b=>b.addEventListener('click',()=>moderate(b.dataset.approve,'approved')));
  document.querySelectorAll('[data-reject]').forEach(b=>b.addEventListener('click',()=>moderate(b.dataset.reject,'rejected')));
}

function runSearch() {
  const q=state.search.toLowerCase();
  const matches=state.listings.filter(x=>x.status==='approved' && (!q || `${x.title} ${x.description} ${x.type}`.toLowerCase().includes(q)) && (state.county==='All counties'||x.county==='National'||x.county===state.county));
  const demos=demoItems.filter(x=>(!q||`${x.title} ${x.description}`.toLowerCase().includes(q))&&(state.county==='All counties'||x.county==='National'||x.county===state.county));
  state.page='results';render();
  const main=document.querySelector('#main');
  main.innerHTML=`<section class="page-intro"><span class="eyebrow">SEARCH GENZ HUB</span><h1>Search results</h1><p>Showing results for “${esc(state.search||'all topics')}” · ${esc(state.county)}</p></section><div class="listing-grid">${[...matches,...demos].length?[...matches,...demos].map(listingCard).join(''):'<div class="empty-state">No matching listings found. Try another search or county.</div>'}</div>`;
}

function filterListings() {
  const q=(document.querySelector('#listSearch')?.value||'').toLowerCase();
  const c=document.querySelector('#listCounty')?.value||'All counties';
  const cards=[...document.querySelectorAll('#listingGrid .listing-card')];
  cards.forEach(card=>{const text=card.textContent.toLowerCase();card.style.display=(!q||text.includes(q))?'':'none';});
  // County filtering is applied by the backend query on live records; cards show their county label.
  if(c!=='All counties') cards.forEach(card=>{if(!card.textContent.includes(c)&&!card.textContent.includes('National'))card.style.display='none';});
}

async function submitForm(e) {
  e.preventDefault();
  if(!supabase||!state.user)return toast('Sign in and connect the database before submitting.');
  const fd=new FormData(e.currentTarget);const kind=fd.get('kind');const title=fd.get('title').toString().trim();const description=fd.get('description').toString().trim();const county=fd.get('county').toString();const source=fd.get('source_url').toString().trim();const contact=fd.get('contact').toString().trim();
  if(source && !/^https:\/\//i.test(source))return toast('Please use a secure https:// source link.');
  if(kind==='business') {
    const {error}=await supabase.from('businesses').insert({name:title,description,county,website:source||null,contact:contact||null,owner_id:state.user.id,status:'pending'});
    if(error)return toast(error.message);
  } else {
    const type=kind==='opportunity'?'opportunities':kind;
    const {error}=await supabase.from('listings').insert({type,title,description,county,source_url:source||null,owner_id:state.user.id,status:'pending'});
    if(error)return toast(error.message);
  }
  e.currentTarget.reset();toast('Submitted for review. Thank you!');navigate('home');
}

async function moderate(id,status) {
  if(!supabase||!state.isAdmin)return toast('Administrator access required.');
  const {error}=await supabase.from('listings').update({status}).eq('id',id);
  if(error)return toast(error.message);
  await refreshData();toast(`Submission ${status}.`);
}

async function refreshData() {
  if(!supabase){render();return;}
  const {data:{session}}=await supabase.auth.getSession();
  state.user=session?.user||null;state.isAdmin=false;
  if(state.user){
    const {data:admin}=await supabase.from('admin_users').select('user_id').eq('user_id',state.user.id).maybeSingle();
    state.isAdmin=!!admin;
  }
  const [{data:listings},{data:businesses},{data:posts}]=await Promise.all([
    supabase.from('listings').select('*').in('status',state.isAdmin?['pending','approved']:['approved']).order('created_at',{ascending:false}).limit(100),
    supabase.from('businesses').select('*').eq('status','approved').order('created_at',{ascending:false}).limit(100),
    supabase.from('community_posts').select('*').eq('status','approved').order('created_at',{ascending:false}).limit(50)
  ]);
  state.listings=listings||[];state.businesses=businesses||[];state.posts=posts||[];
  render();
}

function render(){shell();}
if(supabase){
  supabase.auth.onAuthStateChange(()=>{setTimeout(refreshData,0);});
}
if(configured) refreshData(); else render();
