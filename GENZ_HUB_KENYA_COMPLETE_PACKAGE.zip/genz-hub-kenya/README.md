# GENZ HUB KENYA — Complete starter package

**Tagline:** Your Life. Your Opportunities. Your Voice.  
**Audience:** Kenyan youth across all 47 counties.

This is a complete, mobile-first web application starter with:
- Six departments: Opportunities, Campus Corner, Hustle Market, Digital Academy, Gen Z Voice and Kenya Today.
- County selector covering all 47 counties.
- English / Kiswahili interface toggle.
- Search and responsive mobile layout.
- Supabase email/password authentication.
- Opportunity and business submissions.
- Admin approval workflow for listings.
- Public directory displays approved listings only.
- SQL schema and Row Level Security (RLS) policies.
- Netlify deployment configuration.

## Important: what is and is not live

The website interface can be previewed without connecting a database. Demonstration cards are clearly labelled and are not real vacancies.

To activate registration, submissions, published listings and the admin dashboard, you must connect your own Supabase project and configure its keys and database. A secure production application cannot be deployed with your private credentials pre-filled by someone else.

The starter intentionally does not include fake user accounts, invented jobs, a public unmoderated feed, payment collection or a service-role key in the browser.

## Easiest Android launch route

You will need:
- A GitHub account.
- A Supabase account (free tier may be sufficient for an initial test; check current limits).
- A Netlify account (or another static host that supports environment variables and Vite builds).

### Step 1 — Create the database
1. Sign in at https://supabase.com/ and create a new project.
2. Open **SQL Editor** → **New query**.
3. Open `supabase/schema.sql` from this package, copy its entire contents and paste into the SQL editor.
4. Press **Run** and confirm there are no errors.

### Step 2 — Get the public connection keys
1. In Supabase, open **Project Settings → API** (or **Data API / API Keys**, depending on the current dashboard).
2. Copy the Project URL.
3. Copy the publishable key (or legacy anon public key).
4. These two public browser values are intended for a frontend protected by the included RLS policies. Never use the `service_role` / secret key in this project.

### Step 3 — Put the project on GitHub
1. Extract the ZIP on your phone or upload its files to a new GitHub repository.
2. Keep the folder structure exactly as supplied.
3. Make sure `package.json`, `index.html`, `src/`, `supabase/` and `netlify.toml` are at the repository root.
4. In GitHub, open **Add file → Upload files**, upload the extracted project contents, then commit.

### Step 4 — Deploy once with Netlify
1. Open https://app.netlify.com/ and sign in.
2. Choose **Add new project → Import an existing project** and connect GitHub.
3. Select your GENZ HUB KENYA repository.
4. Build command: `npm run build`
5. Publish directory: `dist`
6. Before deploying, open **Site configuration → Environment variables** and add:
   - `VITE_SUPABASE_URL` = your Supabase Project URL
   - `VITE_SUPABASE_ANON_KEY` = your Supabase publishable/anon key
7. Deploy. Netlify will build and publish the site. Future GitHub commits trigger redeployment.

### Step 5 — Create your administrator account
1. Open the deployed website and create an account using your own email.
2. Confirm the email if Supabase asks you to.
3. In Supabase, open **Authentication → Users** and copy your account UUID.
4. Open **SQL Editor** and run this statement, replacing the placeholder with your own UUID:

```sql
insert into public.admin_users (user_id)
values ('YOUR-AUTH-USER-UUID');
```

5. Sign out and sign in again on the website. Open your account menu; the Admin Dashboard should appear.
6. Only add trusted administrators. Never share your account password.

## How moderation works
- A signed-in user submits an opportunity or business.
- It enters the database with `pending` status.
- An administrator reviews it.
- Only approved records are publicly visible.
- Never publish an opportunity without checking its original source, date, location, eligibility and application deadline.

## Current limitations / next development work
This is a functional first release foundation, not a finished national service. The current interface includes opportunity and business moderation; the database also prepares a community-post table, but public community posting UI, notifications, password reset, profile management, image uploads, reporting tools and advanced moderation still need to be built and tested before broad public launch.

The site uses external links to third-party resources. Verify the destination and its current availability before promoting it. No guarantee of jobs, funding or business success is made.

## Local preview (optional)
On a computer with Node.js installed:

```bash
npm install
cp .env.example .env
# Add your Supabase URL and public key to .env
npm run dev
```

## Safety and privacy
- Do not collect national ID numbers, passwords, sensitive personal details or unnecessary user data.
- Publish a privacy notice and terms before public registration.
- Provide a contact/reporting channel and respond to scam reports.
- Set an appropriate minimum age and safeguarding process for your audience.
- Keep Supabase RLS enabled. Never expose service-role credentials in frontend code.
- Test with a separate non-admin account before inviting the public.

## Project identity
GENZ HUB KENYA  
**Your Life. Your Opportunities. Your Voice.**
